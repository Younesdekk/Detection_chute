import cv2 as cv
import argparse
import pygame
from picamera2 import Picamera2

# Initialisation de pygame pour la gestion du son
pygame.mixer.init()

# Variables globales
fall_count = 0
fall_sound_count = 0
prev_head_position = None
prev_timestamp = None
vertical_speed = 0

# Corps du programme
def main():
    global fall_count, fall_sound_count, prev_head_position, prev_timestamp, vertical_speed

    parser = argparse.ArgumentParser()
    parser.add_argument('--thr', default=0.2, type=float, help='Valeur seuil pour la carte de chaleur des parties de la pose')
    parser.add_argument('--width', default=368, type=int, help='Redimensionner l\'entrée à une largeur spécifique.')
    parser.add_argument('--height', default=368, type=int, help='Redimensionner l\'entrée à une hauteur spécifique.')

    args = parser.parse_args()

    BODY_PARTS = {"Nose": 0, "Neck": 1, "RShoulder": 2, "RElbow": 3, "RWrist": 4,
                  "LShoulder": 5, "LElbow": 6, "LWrist": 7, "RHip": 8, "RKnee": 9,
                  "RAnkle": 10, "LHip": 11, "LKnee": 12, "LAnkle": 13, "REye": 14,
                  "LEye": 15, "REar": 16, "LEar": 17, "Background": 18}

    inWidth = args.width
    inHeight = args.height

    # Chargement du modèle
    net = cv.dnn.readNetFromTensorflow("graph_opt.pb")

    # Initialisation de la caméra Raspberry Pi
    try:
        picam2 = Picamera2()  # Assurez-vous d'avoir le bon numéro de caméra spécifié
        camera_config = picam2.create_preview_configuration()
        picam2.configure(camera_config)
        picam2.start()
    except Exception as e:
        print("Erreur lors de l'initialisation de la caméra:", e)
        exit(1)

    # Chargement du son à jouer en cas de chute
    fall_sound = pygame.mixer.Sound('sound.mp3')  # Assurez-vous d'avoir un fichier 'sound.mp3' dans le même répertoire que votre script

    while True:
        try:
            im = picam2.capture_array()
            im = cv.cvtColor(im, cv.COLOR_BGR2RGB)  # Convertir l'image en RGB
            im = cv.resize(im, (inWidth, inHeight))  # Redimensionner l'image d'entrée

            frameWidth = im.shape[1]
            frameHeight = im.shape[0]

            # Prétraitement de l'image
            net.setInput(cv.dnn.blobFromImage(im, 1.0, (inWidth, inHeight), (127.5, 127.5, 127.5), swapRB=True, crop=False))

            # Passage de l'image à travers le réseau
            out = net.forward()
            out = out[:, :19, :, :]

            assert(len(BODY_PARTS) == out.shape[1])

            # Extraction des points de la pose
            points = []
            for i in range(len(BODY_PARTS)):
                heatMap = out[0, i, :, :]
                _, conf, _, point = cv.minMaxLoc(heatMap)
                x = (frameWidth * point[0]) / out.shape[3]
                y = (frameHeight * point[1]) / out.shape[2]
                points.append((int(x), int(y)) if conf > args.thr else None)

            # Calcul de la vitesse verticale
            current_head_position = points[BODY_PARTS["Neck"]]
            current_timestamp = cv.getTickCount()

            if current_head_position is not None and prev_head_position is not None and prev_timestamp is not None:
                # Calcul de la vitesse verticale en pixels par seconde
                vertical_speed = (current_head_position[1] - prev_head_position[1]) / ((current_timestamp - prev_timestamp) / cv.getTickFrequency())
                
                # Seuil pour la détection de chute
                fall_threshold = 320  # Ajuster selon les besoins

                # Détection de chute
                if vertical_speed > fall_threshold:
                    fall_count += 1
                    print("Chute détectée!")
                    
                    while fall_sound_count < 4:
                        
                        # Jouer le son en cas de chute
                        fall_sound.play()
                        fall_sound_count += 1
                        pygame.time.delay(1000)
                        
                    fall_sound_count = 0
                
            # Mise à jour des variables pour la prochaine itération
            prev_head_position = current_head_position
            prev_timestamp = current_timestamp

            # Affichage du nombre de chutes en permanence à l'écran
            cv.putText(im, f'Nombre de Chutes: {fall_count}', (10, 50), cv.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

            # Affichage de la vitesse verticale
            cv.putText(im, f'Vitesse Verticale: {vertical_speed:.2f} pixels/s', (10, 80), cv.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            # Affichage des schémas de détection des parties du corps
            for pair in [[1, 2], [1, 5], [2, 3], [3, 4], [5, 6], [6, 7], [1, 8], [8, 9], [9, 10], [1, 11], [11, 12], [12, 13], [1, 0], [0, 14], [14, 16], [0, 15], [15, 17]]:
                partFrom = pair[0]
                partTo = pair[1]

                if points[partFrom] and points[partTo]:
                    cv.line(im, points[partFrom], points[partTo], (0, 255, 0), 3)
                    cv.ellipse(im, points[partFrom], (3, 3), 0, 0, 360, (0, 0, 255), cv.FILLED)
                    cv.ellipse(im, points[partTo], (3, 3), 0, 0, 360, (0, 0, 255), cv.FILLED)

            cv.imshow('OpenPose using OpenCV', im)

            # Sortir de la boucle lorsque la touche 'q' est pressée
            if cv.waitKey(1) & 0xFF == ord('q'):
                break

        except KeyboardInterrupt:
            break

    # Arrêt de la caméra et libération des ressources
    picam2.stop()
    cv.destroyAllWindows()

if __name__ == "__main__":
    main()
